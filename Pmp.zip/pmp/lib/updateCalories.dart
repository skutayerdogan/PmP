import 'package:flutter/cupertino.dart';

class UpdateCalories extends StatefulWidget {
  const UpdateCalories({Key? key}) : super(key: key);

  @override
  State<UpdateCalories> createState() => _UpdateCaloriesState();
}

class _UpdateCaloriesState extends State<UpdateCalories> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
