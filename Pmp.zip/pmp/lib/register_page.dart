import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:pmp/home_page.dart';
import 'package:pmp/login_page.dart';
class RegisterPage extends StatefulWidget {
  final VoidCallback showLoginPage;
  const RegisterPage({Key? key,required this.showLoginPage}) : super(key: key);

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final formKey = GlobalKey<FormState>();
  bool isPasswordVisible = true;
  List<String> items = ['Male','Female'];
  String? dropController;
  int caloriesBurned = 0;
  int caloriesTaken = 0;
  final _email_controller = TextEditingController();
  final _password_controller = TextEditingController();
  final _first_name_controller = TextEditingController();
  final _last_name_controller = TextEditingController();
  final _age_controller = TextEditingController();
  final _height_controller = TextEditingController();
  final _weight_controller = TextEditingController();



  @override
  void dispose() {
    _email_controller.dispose();
    _password_controller.dispose();
    super.dispose();
  }

  Future signUp() async {
    final isValid = formKey.currentState!.validate();
    if(!isValid) return;

    try{
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _email_controller.text.trim(),
          password: _password_controller.text.trim());
    }on FirebaseAuthException catch(e){
      print(e);
    }
    addUserDetails(
        _first_name_controller.text.trim(),
        _last_name_controller.text.trim(),
        _email_controller.text.trim(),
        int.parse(_age_controller.text.trim()),
        double.parse(_weight_controller.text.trim()),
        double.parse(_height_controller.text.trim()),
        dropController!.trim(),
        caloriesBurned,
        caloriesTaken,
    );
  }
  Future addUserDetails(
      String firstName,String lastName,String email,int age,double weight,double height,String gender,int caloriesBurned,int caloriesTaken) async {
    await FirebaseFirestore.instance.collection('users').add({
      'first name': firstName,
      'last name': lastName,
      'e-mail': email,
      'age': age,
      'height': height,
      'weight': weight,
      'gender': gender,
      'caloriesBurned': caloriesBurned,
      'caloriesTaken': caloriesTaken,
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: Form(
        key: formKey,
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 20,
                  ),
                  Text(
                    'Sign Up',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                        color: Colors.redAccent,
                        fontSize: 27
                    ),
                  ),
                  Container(
                    height: 15,
                  ),
                  Text(
                    'Please fill the required information below...',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 15
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: TextFormField(
                      keyboardType: TextInputType.name,
                      controller: _first_name_controller,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.redAccent),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        labelText: 'First Name',
                        fillColor: Colors.grey.shade50,
                        filled: true,
                      ),
                      validator: (value) {
                        if(value!.isEmpty || !RegExp(r'^[a-z A-Z]+$').hasMatch(value!)){
                          return 'Enter Correct Name';
                        }else{
                          return null;
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: TextFormField(
                      keyboardType: TextInputType.name,
                      controller: _last_name_controller,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.redAccent),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        labelText: 'Last Name',
                        fillColor: Colors.grey.shade50,
                        filled: true,

                      ),
                      validator: (value) {
                        if(value!.isEmpty || !RegExp(r'^[a-z A-Z]+$').hasMatch(value!)){
                          return 'Enter Correct Surname';
                        }else{
                          return null;
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: TextFormField(
                      keyboardType: TextInputType.number,
                      controller: _age_controller,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.redAccent),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        labelText: 'Age',
                        fillColor: Colors.grey.shade50,
                        filled: true,
                      ),
                      validator: (value) {
                        if(value!.isEmpty || !RegExp(r'^[0-9]+$').hasMatch(value!)){
                          return 'Enter Correct Age';
                        }else{
                          return null;
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: TextFormField(
                      keyboardType: TextInputType.number,
                      controller: _height_controller,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.redAccent),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        suffix: Text(
                          style: TextStyle(
                            color: Colors.redAccent
                          ),
                            'cm',
                        ),
                        labelText: 'Height',
                        fillColor: Colors.grey.shade50,
                        filled: true,
                      ),
                      validator: (value) {
                        if(value!.isEmpty || !RegExp(r'^[0-9]+$').hasMatch(value!)){
                          return 'Enter Correct Height';
                        }else{
                          return null;
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: TextFormField(
                      keyboardType: TextInputType.number,
                      controller: _weight_controller,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.redAccent),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        suffix: Text(
                        style: TextStyle(color: Colors.redAccent),
                        'kg'
                        ),
                        labelText: 'Weight',
                        fillColor: Colors.grey.shade50,
                        filled: true,
                      ),
                      validator: (value) {
                        if(value!.isEmpty || !RegExp(r'^[0-9]+$').hasMatch(value!)){
                          return 'Enter Correct Weight';
                        }else{
                          return null;
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: TextFormField(
                      keyboardType: TextInputType.emailAddress,
                      controller: _email_controller,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.redAccent),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        labelText: 'E-mail',
                        fillColor: Colors.grey.shade50,
                        filled: true,
                      ),
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      validator: (email) =>
                      email != null && !EmailValidator.validate(email)
                          ? 'Enter a valid Email'
                          : null,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: TextFormField(
                      obscureText: isPasswordVisible,
                      controller: _password_controller,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.redAccent),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        labelText: 'Password',
                        suffixIcon: IconButton(
                          icon: isPasswordVisible
                              ? Icon(Icons.visibility_off)
                              : Icon(Icons.visibility),
                          onPressed: () => setState(() {
                            isPasswordVisible = !isPasswordVisible;
                          }),
                        ),
                        fillColor: Colors.grey.shade50,
                        filled: true,
                      ),
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      validator: (value) =>
                      value != null && value.length < 6
                          ? 'Enter min. 6 characters'
                          : null,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: DropdownButtonFormField2(
                      decoration: InputDecoration(
                        isDense: true,
                        contentPadding: EdgeInsets.zero,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      hint: Text(
                          'Gender'
                      ),
                        icon: const Icon(Icons.arrow_drop_down),
                        iconSize: 30,
                        buttonHeight: 60,
                        validator: (value) {
                          if (value == null) {
                            return 'Please select gender.';
                          }
                        },
                        dropdownDecoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15)
                        ),
                        value: dropController,
                        items: items.map(
                                (e) => DropdownMenuItem(child: Text(e), value: e,)
                        ).toList(),
                        onChanged: (value) {
                          setState(() {
                            dropController = value;
                          });
                        }
                        ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,0),
                    child: GestureDetector(
                      onTap: signUp,
                      child: Container(
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.redAccent,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Center(
                          child: Text(
                            'Sign up',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  GestureDetector(
                    onTap: widget.showLoginPage,
                    child: Text(
                      'Back to log in',
                      style: TextStyle(
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
