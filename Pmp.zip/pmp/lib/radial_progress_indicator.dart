import 'package:vector_math/vector_math_64.dart' as math;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RadialProgress extends StatefulWidget {
  final num caloriesTaken;
  final num caloriesBurned;
  const RadialProgress(this.caloriesBurned,this.caloriesTaken , {Key? key}) : super(key: key);

  @override
  State<RadialProgress> createState() => _RadialProgressState();
}

class _RadialProgressState extends State<RadialProgress> {

  final double goalComplete = 0.7;

  @override
  void didUpdateWidget(covariant RadialProgress oldWidget) {
    // TODO: implement didUpdateWidget
      if (oldWidget.caloriesBurned != widget.caloriesBurned) {
        build(context);
      }

  }
  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: CircularPainter(((widget.caloriesBurned * 360) / widget.caloriesTaken)),
      child: Container(
        height: 120,
        width: 120,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Text(
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),

                '${widget.caloriesBurned.toStringAsFixed(0)} cal burned\n ${(widget.caloriesTaken - widget.caloriesBurned).toStringAsFixed(0)} cal left',
              ),
            ),
          ],
        ),
      ),
      // 250 degree
    );
  }
}

class CircularPainter extends CustomPainter {
  double progressInDegrees;

  CircularPainter(this.progressInDegrees);
  @override
  void paint(Canvas canvas, Size size) {

    Paint paint = Paint()
      ..color = Colors.grey
      ..strokeCap =StrokeCap.round
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8.0;  // circles width

    Offset center = Offset(size.width/2, size.height/2);
    canvas.drawCircle(center, size.width/2,paint);

    Paint progress = Paint()
      ..shader = LinearGradient(
          colors: [Colors.redAccent, Colors.pinkAccent ,Colors.purple]).createShader(Rect.fromCircle(center: center, radius: size.width / 2))
      ..strokeCap =StrokeCap.round //Circle border shape
      ..style = PaintingStyle.stroke // shape of filling circle inside (line)
      ..strokeWidth = 8.0;

    canvas.drawArc(Rect.fromCircle(center: center, radius: size.width/2), math.radians(-90), math.radians(progressInDegrees), false, progress);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }

}


