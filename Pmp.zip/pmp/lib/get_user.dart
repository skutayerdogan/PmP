import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:pmp/diet_page.dart';
import 'package:pmp/radial_progress_indicator.dart';
import 'package:pmp/widget/personal_diet_page.dart';
import 'package:pmp/widget/workoutsPage.dart';
import 'package:intl/intl.dart';
num totalCaloriesTaken = 0;
num totalCaloriesBurnt = 0;
class GetUser extends StatefulWidget {
  final String documentId;
  GetUser({Key? key,required this.documentId}) : super(key: key);

  @override
  State<GetUser> createState() => _GetUserState();
}

class _GetUserState extends State<GetUser> {
  var bmi;
  var bm;
  var cal;

  String calculateBMI(double weight,double height) {
    bmi = weight / ((height / 100) * (height / 100));
    if (bmi <= 18.5) {
      return "You are underweight...";
    }
    else if (bmi <= 24.9 && bmi > 18.5) {
      return "You have a normal weight...";
    }
    else {
      return "You are overweight...";
    }
  }

  String getBmi() {
    return '%' + bmi.toStringAsFixed(2);
  }

  int dailyCaloryCalculation(String gender , int age){
    if(age < 35 && gender == 'Male'){
      return 2400;
    }else if(age < 35 && gender == 'Female'){
      return 2000;
    }else if(age > 35 && gender == 'Male'){
      return 2200;
    }else{
      return 1600;
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    CollectionReference user = FirebaseFirestore.instance.collection('users');
    return FutureBuilder<DocumentSnapshot>(
        future: user.doc(widget.documentId).get(),
        builder: (context,snapshot) {
          if(snapshot.connectionState == ConnectionState.done) {
            Map<String,dynamic> data = snapshot.data!.data() as Map<String,dynamic>;
            return Stack(
              children:<Widget>[
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        bottom: Radius.circular(40),
                      ),
                      child: Container(
                        color: Colors.white,
                        padding: EdgeInsets.only(top: 0,left: 30,right: 15,bottom: 10),
                        child: Column(
                          children: [
                            ListTile(
                              title: Text(
                                '${DateFormat('EEEE').format(today)}, ${DateFormat('D MMMM').format(today)}',
                                style: TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w400
                                ),
                              ),
                              subtitle: Text(
                                'Hello, ${data['first name']}',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800
                                ),
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left:10),
                                    decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.redAccent.shade100.withOpacity(0.2),
                                  ),
                                  alignment: Alignment.centerLeft,
                                  padding: EdgeInsets.only(left: 15),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      RichText(
                                        text: TextSpan(
                                          text: 'Age: ',
                                          style: DefaultTextStyle.of(context).style,
                                          children: <TextSpan>[
                                            TextSpan(
                                                text: '${data['age']}',
                                                style: TextStyle(fontWeight: FontWeight.bold,color: Colors.redAccent)),
                                          ],
                                        ),
                                      ),
                                      RichText(
                                        text: TextSpan(
                                          text: 'Height: ',
                                          style: DefaultTextStyle.of(context).style,
                                          children: <TextSpan>[
                                            TextSpan(
                                                text: '${data['height']}',
                                                style: TextStyle(fontWeight: FontWeight.bold,color: Colors.redAccent)),
                                            TextSpan(
                                                text: ' cm',
                                                style: TextStyle(fontWeight: FontWeight.w400,color: Colors.black)),
                                          ],
                                        ),
                                      ),
                                      RichText(
                                        text: TextSpan(
                                          text: 'Weight: ',
                                          style: DefaultTextStyle.of(context).style,
                                          children: <TextSpan>[
                                            TextSpan(
                                                text: '${data['weight']}',
                                                style: TextStyle(fontWeight: FontWeight.bold,color: Colors.redAccent)),
                                            TextSpan(
                                                text: ' kg',
                                                style: TextStyle(fontWeight: FontWeight.w400,color: Colors.black)),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 20,left: 20),
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(bottom: 10),
                                        child: Column(
                                          children: [
                                            Text(
                                              style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                              ),
                                              'Total Calories Taken:'
                                            ),
                                            Text(
                                              style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                              ),
                                              ' ${data['caloriesTaken']} '
                                            )
                                          ],
                                        ),
                                      ),
                                      RadialProgress(data['caloriesBurned'] , data['caloriesTaken']),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Container(
                      width: 320,
                      height: 130,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(30)),
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.red,
                            Colors.deepOrange,
                          ]
                        ),
                      ),
                      child: Column(
                        children:   [
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'VIEW WORKOUTS',
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                                fontSize: 25,
                              ),
                            ),
                          ),
                          MaterialButton(
                            onPressed: () {
                              Navigator.push(
                                  context, MaterialPageRoute(
                                  builder: (builder) => workoutsPage(widget.documentId)));
                            },
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 20,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                        Colors.white,
                                        Colors.white54,
                                        ]
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(5)),
                                  ),

                                  child: Image.asset(
                                    "lib/images/muscle.png",
                                    width: 60,
                                    height: 60,
                                    color: Colors.black,
                                  ),
                                ),
                                SizedBox(
                                  width: 25,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Colors.white,
                                          Colors.white54,
                                        ]
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(5)),
                                    color: Colors.grey.withOpacity(0.8),
                                  ),
                                  child: Image.asset(
                                      width: 60,
                                      height: 60,
                                    'lib/images/chest.png',
                                  ),
                                ),
                                SizedBox(
                                  width: 25,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Colors.white,
                                          Colors.white54,
                                        ]
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(5)),
                                    color: Colors.grey.withOpacity(0.8),
                                  ),
                                  child: Image.asset(
                                    width: 60,
                                    height: 60,
                                    'lib/images/back.png',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10 , right: 10),
                          child: Container(
                            width: 150,
                            height: 150,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Colors.green.shade500,
                                    Colors.green.shade300,
                                  ]
                              ),
                            ),
                            child: Column(
                              children: [
                                Padding(
                                  padding: EdgeInsets.all(15.0),
                                  child: Text(
                                    'Personal Diet',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 20,
                                    ),
                                  ),
                                ),
                                MaterialButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context, MaterialPageRoute(
                                        builder: (builder) => PersonalDiet(widget.documentId)));
                                  },
                                  child: Container(
                                      decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: [
                                            Colors.white,
                                            Colors.white54,
                                          ]
                                      ),
                                      borderRadius: BorderRadius.all(Radius.circular(5)),
                                      color: Colors.grey.withOpacity(0.8),
                                    ),
                                    child: Image.asset(
                                      width: 60,
                                      height: 60,
                                      'lib/images/diet.png',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: 200,
                          height: 150,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.blue.shade500,
                                  Colors.blue.shade300,
                                ]
                            ),
                            color: Colors.purple,
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children:  [
                              Text(
                                'Body Mass Index (BMI)\n',
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                calculateBMI(data['weight'],data['height']),
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              Container(
                                width: 70,
                                height: 70,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                ),
                                child: Center(
                                  child: Text(
                                    getBmi(),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ],
            ),
              ]
            );
          }
          return Text('Loading..');
        });
  }
}
