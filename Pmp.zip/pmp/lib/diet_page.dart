import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pmp/get_user.dart';
import 'package:pmp/home_page.dart';
import 'package:pmp/model/set_personal_diet_model.dart';
import 'model/personal_diet_model.dart';
class DietPage extends StatefulWidget {
  final SetPersonalDiet setPersonalDiet;
  final String documentId;
  const DietPage(this.documentId,this.setPersonalDiet, {Key? key}) : super(key: key);

  @override
  State<DietPage> createState() => _DietPageState();
}

class _DietPageState extends State<DietPage> {
  final controller = PageController();
  late Food currentFood;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    currentFood = widget.setPersonalDiet.dietList.first;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
            currentFood.name
        ),
        backgroundColor: Colors.green,
        centerTitle: true,
        elevation: 0,
      ),
      body: DietFood(),
    );
  }
  Widget DietFood(){
    return PageView(
      scrollDirection: Axis.horizontal,
      controller: controller,
      onPageChanged: (index) => setState(() {
        currentFood = widget.setPersonalDiet.dietList[index];
      }),
      children: widget.setPersonalDiet.dietList.map((exercise) => Page(widget.documentId,currentFood)
      ).toList(),
    );
  }
}
class Page extends StatefulWidget {
  final Food currentFood;
  final String documentId;
  const Page(this.documentId,this.currentFood, {Key? key}) : super(key: key);

  Future<void> updateUser(int calories) {
    CollectionReference users = FirebaseFirestore.instance.collection('users');
    totalCaloriesTaken += calories;
    return users
        .doc(documentId)
        .update({'caloriesTaken': totalCaloriesTaken})
        .then((value) => print("User Updated"))
        .catchError((error) => print("Failed to update user: $error"));
  }

  @override
  State<Page> createState() => _PageState();
}

class _PageState extends State<Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: Image.asset(
                    width: 150,
                    height: 150,
                    widget.currentFood.imageUrl,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.green.shade100.withOpacity(0.5),
                  ),
                  child: Text(
                    style:TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                    ),
                    'Name: ${widget.currentFood.name}',
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.deepOrange.shade100.withOpacity(0.5),
                  ),
                  child: Text(
                    style:TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                    ),
                    'Amount: ${widget.currentFood.amount}',
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.deepOrange.shade100.withOpacity(0.5),
                  ),
                  child: Text(
                    style:TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                    ),
                    'Calory: ${widget.currentFood.calory} cal',
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.blueGrey.shade100.withOpacity(0.5),
                  ),
                  child: Text(
                    style:TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                    ),
                    '${widget.currentFood.description}',
                  ),
                ),
              ),
              ElevatedButton(
                  onPressed: () => widget.updateUser(widget.currentFood.calory),
                  child: Text('Add')),
              ElevatedButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (builder)=>HomePage()));
                  },
                  child: Text(
                    'Save'
                  ))
            ],
          ),
        ),
      ),
    );
  }
}



