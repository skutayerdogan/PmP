import 'package:flutter/material.dart';
import 'package:pmp/data/personal_diet_data.dart';
import 'package:pmp/model/set_personal_diet_model.dart';

final setPersonalDiet = [
  SetPersonalDiet(
    name: 'Breakfast',
    dietList: breakfast,
    imageUrl: 'lib/images/breakfast.png',
    color: Colors.green.shade100.withOpacity(0.5),
  ),
  SetPersonalDiet(
    name: 'Lunch',
    dietList: lunch,
    imageUrl: 'lib/images/lunch.png',
    color: Colors.yellow.shade100.withOpacity(0.5),
  ),
  SetPersonalDiet(
    name: 'Dinner',
    dietList: dinner,
    imageUrl: 'lib/images/dinner.png',
    color: Colors.blueAccent.shade100.withOpacity(0.5),
  ),
];