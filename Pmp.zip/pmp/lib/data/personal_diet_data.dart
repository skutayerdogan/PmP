

import 'package:pmp/model/personal_diet_model.dart';

final breakfast = [
  Food(
    name: 'Egg',
    calory: 30,
    amount: 1,
    imageUrl : 'lib/images/egg.png',
    description: 'Gain Weight: Three eggs or more per day\nLose Weight: Three eggs a day for 12 weeks',
  ),
  Food(
    name: 'Oat',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/oat.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Cheese',
    calory: 300,
    amount: 50,
    imageUrl : 'lib/images/cheese.png',
    description: 'Gain Weight: 3-ounce cheese serving per day\nLose Weight: 1-ounce cheese serving per day',
  ),
  Food(
    name: 'Oat',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/yulaf.png',
    description: 'Gain Weight: Three eggs or more per day\nLose Weight: Three eggs a day for 12 weeks',
  ),
  Food(
    name: 'Oat',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/yulaf.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Oat',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/yulaf.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Oat',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/yulaf.png',
    description: 'Lorem ipsum',
  ),
];

final lunch = [
  Food(
    name: 'Chicken',
    calory: 500,
    amount: 250,
    imageUrl : 'lib/images/chicken.png',
    description: 'Lorem ipsum'
  ),
  Food(
    name: 'Rice',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/rice.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Rice',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/rice.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Rice',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/rice.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Rice',
    calory: 200,
    amount: 100,
    imageUrl : 'lib/images/rice.png',
    description: 'Lorem ipsum',
  ),
];

final dinner = [
  Food(
    name: 'Meat',
    calory: 440,
    amount: 300,
    imageUrl : 'lib/images/meat.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Broccoli',
    calory: 10,
    amount: 40,
    imageUrl : 'lib/images/brokoli.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Broccoli',
    calory: 10,
    amount: 40,
    imageUrl : 'lib/images/brokoli.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Broccoli',
    calory: 10,
    amount: 40,
    imageUrl : 'lib/images/brokoli.png',
    description: 'Lorem ipsum',
  ),
  Food(
    name: 'Broccoli',
    calory: 10,
    amount: 40,
    imageUrl : 'lib/images/brokoli.png',
    description: 'Lorem ipsum',
  ),
];