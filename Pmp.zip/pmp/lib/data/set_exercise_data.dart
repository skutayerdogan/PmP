import 'package:flutter/material.dart';
import 'package:pmp/data/exercise_data.dart';
import 'package:pmp/model/set_exercise_model.dart';

final setExercises = [
  SetExercise(
      name: 'Arm',
      exercises: armExercises,
      imageUrl: 'lib/images/muscle.png',
      color: Colors.red.shade100.withOpacity(0.5),
  ),
  SetExercise(
      name: 'Chest',
      exercises: chestExercises,
      imageUrl: 'lib/images/chest.png',
      color: Colors.blue.shade100.withOpacity(0.5),
  ),
  SetExercise(
    name: 'Back',
    exercises: backExercises,
    imageUrl: 'lib/images/back.png',
    color: Colors.green.shade100.withOpacity(0.5),
  ),
  SetExercise(
    name: 'Shoulder',
    exercises: chestExercises,
    imageUrl: 'lib/images/shoulder.png',
    color: Colors.yellow.shade100.withOpacity(0.5),
  ),
  SetExercise(
    name: 'Abs',
    exercises: armExercises,
    imageUrl: 'lib/images/abs.png',
    color: Colors.purple.shade100.withOpacity(0.5),
  ),
];