

import 'package:pmp/model/exercise_model.dart';

final armExercises = [
  Exercise(
      name: 'Biceps',
      reps: 10,
      duration: 40,
      videoUrl: 'https://vimeo.com/538260148',
      calories: 400
  ),
  Exercise(
      name: 'Push Up',
      reps: 10,
      duration: 20,
      videoUrl: 'https://vimeo.com/538260148',
      calories: 600,
  ),
];

final chestExercises = [
  Exercise(
      name: 'Abs',
      reps: 10,
      duration: 40,
      videoUrl: 'https://vimeo.com/538260148',
      calories: 400,
  ),
  Exercise(
      name: 'Push Up',
      reps: 10,
      duration: 40,
      videoUrl: 'https://vimeo.com/538260148',
      calories: 800,
  ),
  Exercise(
    name: 'Push Up',
    reps: 10,
    duration: 40,
    videoUrl: 'https://vimeo.com/538260148',
    calories: 1000,
  ),
];

final backExercises = [
  Exercise(
      name: 'Push Up',
      reps: 10,
      duration: 40,
      videoUrl: 'https://vimeo.com/538260148',
      calories: 500,
  ),
  Exercise(
      name: 'Push Up',
      reps: 10,
      duration: 40,
      videoUrl: 'https://vimeo.com/538260148',
      calories: 700,
  ),
  Exercise(
    name: 'Push Up',
    reps: 10,
    duration: 40,
    videoUrl: 'https://vimeo.com/538260148',
    calories: 590,
  ),
  Exercise(
    name: 'Push Up',
    reps: 10,
    duration: 40,
    videoUrl: 'https://vimeo.com/538260148',
    calories: 320,
  ),
  Exercise(
    name: 'Push Up',
    reps: 10,
    duration: 40,
    videoUrl: 'https://vimeo.com/538260148',
    calories: 460,
  ),
];