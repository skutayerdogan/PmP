import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:pmp/get_user.dart';
import 'package:pmp/practices_page.dart';
import 'package:pmp/widget/workoutsPage.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  User? user = FirebaseAuth.instance.currentUser!;
  List<String> docId = [];
  Future getdocId() async{
    await FirebaseFirestore.instance.collection('users').where(
      'e-mail',isEqualTo: user?.email).get().then(
            (snapshot) => snapshot.docs.forEach(
                    (document) {
                      print(document.reference);
                      if(docId.length < 1) {
                        docId.add(document.reference.id);
                      }
                    }
                    ));
  }
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        leading: MaterialButton(
          child: Icon(Icons.arrow_back),
          onPressed: () {
            FirebaseAuth.instance.signOut();

          },
        ),
        title: Text(
          'Home Page',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
      ),
      body: Center(
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                  child: FutureBuilder(
                    future: getdocId(),
                    builder: (context,snapshot){
                      return ListView.builder(
                        itemCount: docId.length,
                          itemBuilder: (context,index) {
                            return ListTile(
                              title: GetUser(documentId: docId[index]),
                            );
                            },
                      );
                    },
                  ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
