import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:pmp/register_page.dart';


class LoginPage extends StatefulWidget {
  final VoidCallback showRegisterPage;
  const LoginPage({Key? key,required this.showRegisterPage}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final formKey = GlobalKey<FormState>();
  final _email_controller = TextEditingController();
  final _password_controller = TextEditingController();
  bool isPasswordVisible = true;

  Future signIn() async {
    final isValid = formKey.currentState!.validate();
    if(!isValid) return;

    try{
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email_controller.text.trim(),
        password: _password_controller.text.trim(),
      );
    } on FirebaseAuthException catch (e){
      print(e);
      //Utils.showSnackBar(e.message);
    }
  }

  @override
  void dispose() {
    _email_controller.dispose();
    _password_controller.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: Form(
        key: formKey,
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.sports_gymnastics,
                    color: Colors.redAccent,
                    size: 100,
                  ),
                  Container(
                    height: 50,
                  ),
                  Text(
                    'Practices Makes Perfect',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                      fontSize: 30,
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,5),
                    child: TextFormField(
                      keyboardType: TextInputType.emailAddress,
                      controller: _email_controller,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.redAccent),
                            borderRadius: BorderRadius.circular(15)
                        ),
                        suffixIcon: Icon(Icons.email),
                        fillColor: Colors.grey.shade50,
                        filled: true,
                      ),
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      validator: (email) =>
                        email != null && !EmailValidator.validate(email)
                          ? 'Enter a valid Email'
                          : null,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,5),
                    child: Password()
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(30.0,10.0,30.10,5),
                    child: GestureDetector(
                      onTap: signIn,
                      child: Container(
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.redAccent,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Center(
                          child: Text(
                            'Sign in',
                            style: TextStyle(
                              color: Colors.grey.shade100,
                              fontWeight: FontWeight.bold,
                              fontSize: 18
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 20,
                  ),
                  GestureDetector(
                    onTap: widget.showRegisterPage,
                    child: Text(
                      'Register now',
                      style: TextStyle(
                        decoration: TextDecoration.underline,
                        fontSize: 17
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
  Widget Password(){
    return TextFormField(
      obscureText: isPasswordVisible,
      controller: _password_controller,
      decoration: InputDecoration(
        labelText: 'Password',
        suffixIcon: IconButton(
          icon: isPasswordVisible
                ? Icon(Icons.visibility_off)
                : Icon(Icons.visibility),
          onPressed: () => setState(() {
            isPasswordVisible = !isPasswordVisible;
          }),
        ),
        fillColor: Colors.grey.shade50,
        filled: true,
        border: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.redAccent),
          borderRadius: BorderRadius.circular(15)
        ),
      ),
      autovalidateMode: AutovalidateMode.onUserInteraction,
      validator: (value) =>
      value != null && value.length < 6
          ? 'Enter min. 6 characters'
          : null,
    );
  }
}
