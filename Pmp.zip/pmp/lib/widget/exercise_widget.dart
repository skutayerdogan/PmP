import 'package:flutter/cupertino.dart';
import 'package:pmp/exercise_page.dart';
import '../model/set_exercise_model.dart';
import 'package:flutter/material.dart';

class ExerciseWidget extends StatefulWidget {
  final SetExercise setExercise;
  final String documentId;
  var totalCalories;
  ExerciseWidget(this.totalCalories,this.documentId, {Key? key, required this.setExercise}) : super(key: key);

  @override
  State<ExerciseWidget> createState() => _ExerciseWidgetState();
}

class _ExerciseWidgetState extends State<ExerciseWidget> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => ExercisePage(widget.totalCalories,widget.documentId,widget.setExercise),
        )
      ),
      child: Container(
        padding: EdgeInsets.all(16),
        height: 100,
        decoration: BoxDecoration(
          color: widget.setExercise.color,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
            children: [
              ExerciseDescription(),
              SizedBox(
                width:10,
                height: 10,
              ),
              Image.asset(
                height: 50,
                  width: 50,
                  widget.setExercise.imageUrl
              ),
            ],
        ),
      ),
    );
  }

  Widget ExerciseDescription(){
    final exercises = widget.setExercise.exercises.length;

    return
      Expanded(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${widget.setExercise.name}',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 5,),
            Text('$exercises Exercises'),
          ],
        ),
      );
  }
}
