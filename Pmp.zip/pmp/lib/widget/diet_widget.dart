import 'package:flutter/cupertino.dart';
import 'package:pmp/diet_page.dart';
import 'package:pmp/exercise_page.dart';
import 'package:pmp/model/set_personal_diet_model.dart';
import 'package:pmp/widget/personal_diet_page.dart';
import 'package:flutter/material.dart';

class DietWidget extends StatelessWidget {

  final SetPersonalDiet setPersonalDiet;
  final String documentId;
  const DietWidget(this.documentId, {Key? key, required this.setPersonalDiet}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => DietPage(documentId,setPersonalDiet),
      )
      ),
      child: Container(
        padding: EdgeInsets.all(16),
        height: 100,
        decoration: BoxDecoration(
          color: setPersonalDiet.color,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            DietDescription(),
            SizedBox(
              width:10,
              height: 10,
            ),
            Image.asset(
                height: 50,
                width: 50,
                setPersonalDiet.imageUrl
            ),
          ],
        ),
      ),
    );
  }
  Widget  DietDescription(){
    final dietList = setPersonalDiet.dietList.length;

    return
      Expanded(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${setPersonalDiet.name}',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 5,),
            Text('$dietList Meal'),
          ],
        ),
      );
  }
}
