import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pmp/data/set_exercise_data.dart';
import 'package:pmp/data/set_personal_diet_data.dart';
import 'package:pmp/model/set_exercise_model.dart';
import 'package:pmp/model/set_personal_diet_model.dart';

import 'diet_widget.dart';
import 'exercise_widget.dart';

class PersonalDiet extends StatefulWidget {
  final String documentId;
  const PersonalDiet(this.documentId, {Key? key}) : super(key: key);

  @override
  State<PersonalDiet> createState() => _PersonalDietState();
}

class _PersonalDietState extends State<PersonalDiet> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title:Text(
          style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
          'Personal Diet',
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              style: TextStyle(
                color: Colors.green,
                fontSize: 20,
                fontWeight: FontWeight.w500,
              ),
              'Select your food.',
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(10),
              physics: BouncingScrollPhysics(),
              itemCount: setPersonalDiet.length,
              itemBuilder: (context, index) {
                SetPersonalDiet diet = setPersonalDiet[index];
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 5) ,
                  child: (
                      DietWidget(widget.documentId,setPersonalDiet: diet)
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}









