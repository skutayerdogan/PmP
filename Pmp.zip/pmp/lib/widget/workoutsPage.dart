import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pmp/data/set_exercise_data.dart';
import 'package:pmp/model/set_exercise_model.dart';

import 'exercise_widget.dart';

class workoutsPage extends StatefulWidget {
  final String documentId;
  const workoutsPage(this.documentId, {Key? key}) : super(key: key);

  @override
  State<workoutsPage> createState() => _workoutsPageState();
}

class _workoutsPageState extends State<workoutsPage> {
  int totalCalories = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text(
            style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
            'Workouts',
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              style: TextStyle(
                color: Colors.redAccent,
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
              ),
              'Select your exercises',
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(10),
              physics: BouncingScrollPhysics(),
              itemCount: setExercises.length,
              itemBuilder: (context, index) {
                SetExercise exercise = setExercises[index];
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 5) ,
                  child: (
                  ExerciseWidget(totalCalories,widget.documentId ,setExercise: exercise)
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}









