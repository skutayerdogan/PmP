
import 'dart:ffi';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pmp/data/set_exercise_data.dart';
import 'package:pmp/model/exercise_model.dart';
import 'package:pmp/model/set_exercise_model.dart';
import 'package:pmp/widget/exercise_widget.dart';
import 'package:vimeo_video_player/vimeo_video_player.dart';

import 'get_user.dart';
import 'home_page.dart';

class ExercisePage extends StatefulWidget {
  final SetExercise setExercise;
  final String documentId;
  var totalCalories;
  ExercisePage(this.totalCalories,this.documentId,this.setExercise, {Key? key}) : super(key: key);

  @override
  State<ExercisePage> createState() => _ExercisePageState();
}

class _ExercisePageState extends State<ExercisePage> {
  final controller = PageController();
  late Exercise currentExercise;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    currentExercise = widget.setExercise.exercises.first;

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          currentExercise.name
        ),
        backgroundColor: Colors.redAccent,
        centerTitle: true,
        elevation: 0,
      ),
      body: WorkoutExercise(widget.totalCalories),
    );
  }
  Widget WorkoutExercise(int totalCalories){
    return PageView(
      scrollDirection: Axis.horizontal,
      controller: controller,
      onPageChanged: (index) => setState(() {
        currentExercise = widget.setExercise.exercises[index];
      }),
      children: widget.setExercise.exercises.map((exercise) => Page(totalCalories,widget.documentId,currentExercise)
      ).toList(),
    );
  }
}
class Page extends StatefulWidget {
  var totalCalories;
  final Exercise currentExercise;
  final String documentId;
  Page(this.totalCalories,this.documentId,this.currentExercise, {Key? key}) : super(key: key);

  @override
  State<Page> createState() => _PageState();
}

class _PageState extends State<Page> {
  CollectionReference users = FirebaseFirestore.instance.collection('users');

  Future<void> updateUser(int calories) {
    totalCaloriesBurnt += calories;
    return users
        .doc(widget.documentId)
        .update({'caloriesBurned': totalCaloriesBurnt})
        .then((value) => print("User Updated"))
        .catchError((error) => print("Failed to update user: $error"));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            VimeoVideoPlayer(
                vimeoPlayerModel:VimeoPlayerModel(
                    url: widget.currentExercise.videoUrl,
                  systemUiOverlay: const [
                    SystemUiOverlay.top,
                    SystemUiOverlay.bottom,
                  ],
                ),
            ),
            Padding(
              padding: const EdgeInsets.all(5),
              child: Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.green.shade100.withOpacity(0.5),
                ),
                child: Text(
                  style:TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                  ),
                    'Duration: ${widget.currentExercise.duration} Seconds',
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(5),
              child: Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.deepOrange.shade100.withOpacity(0.5),
                ),
                child: Text(
                  style:TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                  ),
                  'Reps: ${widget.currentExercise.reps} Times',
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(5),
              child: Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.blueGrey.shade100.withOpacity(0.5),
                ),
                child: Text(
                  style:TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                  ),
                  '${widget.currentExercise.calories} calories',
                ),
              ),
            ),
            ElevatedButton(
                onPressed: () => updateUser(widget.currentExercise.calories),
                child: Text('Add'),
            ),
            ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (builder)=>HomePage()));
                },
                child: Text(
                  'Save'
                ),
            ),
          ],
        ),
      ),
    );
  }
}




