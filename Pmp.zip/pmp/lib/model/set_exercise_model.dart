import 'dart:ui';
import 'exercise_model.dart';

class SetExercise{
  final String name;
  final List<Exercise> exercises;
  final String imageUrl;
  final Color color;

  SetExercise(
      {
        required this.name,
        required this.exercises,
        required this.imageUrl,
        required this.color
      }
      );
}