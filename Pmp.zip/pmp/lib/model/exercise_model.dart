import 'package:vimeo_video_player/vimeo_video_player.dart';

class Exercise{
  final String name;
  final int reps;
  final int duration;
  final String videoUrl;
  final int calories;

  Exercise({
    required this.name,
    required this.reps,
    required this.duration,
    required this.videoUrl,
    required this.calories
    }
  );
}