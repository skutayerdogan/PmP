import 'dart:ui';
import 'package:pmp/model/personal_diet_model.dart';


class SetPersonalDiet{
  final String name;
  final List<Food> dietList;
  final String imageUrl;
  final Color color;

  SetPersonalDiet(
      {
        required this.name,
        required this.dietList,
        required this.imageUrl,
        required this.color
      }
      );
}