class Food{
  final String name;
  final int calory;
  final int amount;
  final String imageUrl;
  final String description;

  Food({
    required this.name,
    required this.calory,
    required this.amount,
    required this.imageUrl,
    required this.description
  }
      );
}