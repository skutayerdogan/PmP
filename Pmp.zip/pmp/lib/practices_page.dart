import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vimeo_video_player/vimeo_video_player.dart';




class PracticesPage extends StatefulWidget {
  const PracticesPage({Key? key}) : super(key: key);


  @override
  State<PracticesPage> createState() => _PracticesPageState();
}

class _PracticesPageState extends State<PracticesPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green,
      appBar: AppBar(
        title: Text(
          'Practices Videos',
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
        VimeoVideoPlayer(
        vimeoPlayerModel: VimeoPlayerModel(
        url: 'https://vimeo.com/618365496',
          systemUiOverlay: const [
            SystemUiOverlay.top,
            SystemUiOverlay.bottom,
          ],
        ),
    ),
            Container(
              height: 20,
            ),
            VimeoVideoPlayer(
              vimeoPlayerModel: VimeoPlayerModel(
                url: 'https://vimeo.com/538260148',
                systemUiOverlay: const [
                  SystemUiOverlay.top,
                  SystemUiOverlay.bottom,
                ],
              ),
            ),
            VimeoVideoPlayer(
              vimeoPlayerModel: VimeoPlayerModel(
                url: 'https://vimeo.com/538260148',
                systemUiOverlay: const [
                  SystemUiOverlay.top,
                  SystemUiOverlay.bottom,
                ],
              ),
            ),
            VimeoVideoPlayer(
              vimeoPlayerModel: VimeoPlayerModel(
                url: 'https://vimeo.com/538260148',
                systemUiOverlay: const [
                  SystemUiOverlay.top,
                  SystemUiOverlay.bottom,
                ],
              ),
            ),
          ],
        ),
      )
    );
  }
}