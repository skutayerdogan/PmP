package com.example.pmp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
